import ComHeader from './src/components/ComHeader'
import ComAside from './src/components/ComAside'
import storeCom from './src/utils/store.js'
export  {
  ComHeader,
  ComAside,
  storeCom
}