<template>
  <div id="app">
    <!--<top></top>
    <aside-t></aside-t>
    <router-view/>-->
    <el-container>
      <el-header height="70px">
        <com-header></com-header>
      </el-header>
      <el-container>
        <!--<el-aside width="200px"><aside-list></aside-list></el-aside>-->
        <com-aside></com-aside>
        <el-main>
          <!--<v-Tags></v-Tags>-->
          <div class="main_con">
           <!--<keep-alive>
               <router-view v-if="$route.meta.keepAlive"></router-view>
           </keep-alive>-->
           <router-view ></router-view>
          </div>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>
import ComHeader from './components/ComHeader'
import ComAside from './components/ComAside'
import storeCom from './utils/store.js'
//import atop from './components/common/top'
//import AsideList from './components/common/asidelist'
//import vTags from './components/common/Tags'
export default {
  name: 'App',
 data () {
    return {
      projectdetail :{"id":403,"username":"isky_u_gtj_zyj","name":"周云剑测试","email":"1@qq.com","deptName":"国土局","status":1,"createdDate":"2019-05-08 10:29","password":null,"oldPassword":null,"type":1,"identityCard":"","pids":null,"linkTel":"","moveTel":"13561123456","faxTel":"","qq":"","msn":"","mailCode":"","personalPage":"","userCode":"","positionName":null,"positionId":null,"deptId":12,"uniqueNumber":"888888888888888888","roleList":[{"id":136,"isDelete":null,"createdBy":null,"createdDate":null,"lastUpdatedBy":null,"lastUpdatedDate":null,"userId":null,"roleId":null,"roleName":"resource_provider","note":"资源提供方（共享交换特有角色，勿删）","menus":null}],"menuList":[{"id":759,"pid":0,"menuType":1,"menuSort":null,"orderId":null,"menuName":null,"menuText":"大数据共享交换new","menuUrl":"http://bigdev02.isky.com:8500","sysType":null,"icon":"el-icon-analysis","children":[{"id":760,"pid":759,"menuType":1,"menuSort":null,"orderId":null,"menuName":null,"menuText":"首页","menuUrl":"/a","sysType":null,"icon":"ex_home","children":[{"id":761,"pid":760,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"概览","menuUrl":"/previewlist","sysType":null,"icon":"","children":[]},{"id":762,"pid":760,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"待办事项","menuUrl":"/toDoThingsInfo","sysType":null,"icon":"","children":[]}]},{"id":764,"pid":759,"menuType":1,"menuSort":null,"orderId":null,"menuName":null,"menuText":"资源目录","menuUrl":"/b","sysType":null,"icon":"ex_resource","children":[{"id":769,"pid":764,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"目录管理","menuUrl":"/resList","sysType":null,"icon":"","children":[]},{"id":770,"pid":764,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"资源管理","menuUrl":"/managelist","sysType":null,"icon":"","children":[]},{"id":771,"pid":764,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"资源编目","menuUrl":"/listResourceCataloging","sysType":null,"icon":"","children":[]},{"id":772,"pid":764,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"资源分类","menuUrl":"/ClassificationList","sysType":null,"icon":"","children":[]}]},{"id":765,"pid":759,"menuType":1,"menuSort":null,"orderId":null,"menuName":null,"menuText":"文件查询","menuUrl":"/c","sysType":null,"icon":"ex_file","children":[{"id":773,"pid":765,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"文件查询","menuUrl":"/listfileQuery","sysType":null,"icon":"","children":[]}]},{"id":766,"pid":759,"menuType":1,"menuSort":null,"orderId":null,"menuName":null,"menuText":"数据交换","menuUrl":"/d","sysType":null,"icon":"ex_changedata","children":[{"id":774,"pid":766,"menuType":1,"menuSort":null,"orderId":null,"menuName":null,"menuText":"前置机","menuUrl":"/qian","sysType":null,"icon":"","children":[{"id":776,"pid":774,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"前置机管理","menuUrl":"/frontMachineManage","sysType":null,"icon":"","children":[{"id":816,"pid":776,"menuType":3,"menuSort":null,"orderId":null,"menuName":null,"menuText":"启用或停止","menuUrl":"/machineBase/startOrStop","sysType":null,"icon":"","children":[]}]},{"id":777,"pid":774,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"前置机数据查询","menuUrl":"/frontMachineDatasQuery","sysType":null,"icon":"","children":[]},{"id":778,"pid":774,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"前置机交换查询","menuUrl":"/frontMachineExchangeQuery","sysType":null,"icon":"","children":[]},{"id":817,"pid":774,"menuType":3,"menuSort":null,"orderId":null,"menuName":null,"menuText":"新增前置机管理","menuUrl":"/machineBase/insertOne","sysType":null,"icon":"","children":[]},{"id":818,"pid":774,"menuType":3,"menuSort":null,"orderId":null,"menuName":null,"menuText":"修改前置机管理","menuUrl":"/machineBase/updateOneById","sysType":null,"icon":"","children":[]}]},{"id":775,"pid":766,"menuType":1,"menuSort":null,"orderId":null,"menuName":null,"menuText":"交换服务","menuUrl":"/t","sysType":null,"icon":"","children":[{"id":779,"pid":775,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"交换服务管理","menuUrl":"/exchangeServerManage","sysType":null,"icon":"","children":[]},{"id":780,"pid":775,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"交换命令查询","menuUrl":"/exchangeOrderQuery","sysType":null,"icon":"","children":[]},{"id":781,"pid":775,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"交换任务计划","menuUrl":"/exchangeTaskPlan","sysType":null,"icon":"","children":[]},{"id":782,"pid":775,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"数据对账","menuUrl":"/datasCheck","sysType":null,"icon":"","children":[]},{"id":783,"pid":775,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"手工同步","menuUrl":"/manualSync","sysType":null,"icon":"","children":[{"id":814,"pid":783,"menuType":3,"menuSort":null,"orderId":null,"menuName":null,"menuText":"增量同步","menuUrl":"info/manualIncMoveData","sysType":null,"icon":"","children":[]},{"id":815,"pid":783,"menuType":3,"menuSort":null,"orderId":null,"menuName":null,"menuText":"全量同步","menuUrl":"/info/manualFullMoveData","sysType":null,"icon":"","children":[]}]}]}]},{"id":767,"pid":759,"menuType":1,"menuSort":null,"orderId":null,"menuName":null,"menuText":"数据清洗","menuUrl":"/e","sysType":null,"icon":"ex_clean","children":[{"id":784,"pid":767,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"清洗服务管理","menuUrl":"/listCleanService","sysType":null,"icon":"","children":[{"id":807,"pid":784,"menuType":3,"menuSort":null,"orderId":null,"menuName":null,"menuText":"新增清洗服务","menuUrl":"/cleanServer/save","sysType":null,"icon":"","children":[]},{"id":808,"pid":784,"menuType":3,"menuSort":null,"orderId":null,"menuName":null,"menuText":"修改清洗服务","menuUrl":"/cleanServer/edit","sysType":null,"icon":"","children":[]},{"id":809,"pid":784,"menuType":3,"menuSort":null,"orderId":null,"menuName":null,"menuText":"删除清洗服务","menuUrl":"/cleanServer/del","sysType":null,"icon":"","children":[]},{"id":810,"pid":784,"menuType":3,"menuSort":null,"orderId":null,"menuName":null,"menuText":"启动,暂停清洗服务","menuUrl":"/cleanServer/changeStatus","sysType":null,"icon":"","children":[]}]},{"id":795,"pid":767,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"预处理规则","menuUrl":"/listEventcreateCleanRule","sysType":null,"icon":"","children":[{"id":811,"pid":795,"menuType":3,"menuSort":null,"orderId":null,"menuName":null,"menuText":"删除自定义规则","menuUrl":"/customRule/del","sysType":null,"icon":"","children":[]},{"id":812,"pid":795,"menuType":3,"menuSort":null,"orderId":null,"menuName":null,"menuText":"修改自定义规则","menuUrl":"/customRule/edit","sysType":null,"icon":"","children":[]},{"id":813,"pid":795,"menuType":3,"menuSort":null,"orderId":null,"menuName":null,"menuText":"新增自定义规则","menuUrl":"/customRule/save","sysType":null,"icon":"","children":[]}]},{"id":796,"pid":767,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"清洗日志查询","menuUrl":"/listCleanLog","sysType":null,"icon":"","children":[]},{"id":797,"pid":767,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"问题数据查询","menuUrl":"/listProblemDataQuery","sysType":null,"icon":"","children":[]},{"id":798,"pid":767,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"清洗结果统计","menuUrl":"/listCleanresult","sysType":null,"icon":"","children":[]}]},{"id":768,"pid":759,"menuType":1,"menuSort":null,"orderId":null,"menuName":null,"menuText":"申请审批","menuUrl":"/f","sysType":null,"icon":"ex_apply","children":[{"id":786,"pid":768,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"待我审批","menuUrl":"/listMyWork","sysType":null,"icon":"","children":[]},{"id":787,"pid":768,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"我已审批","menuUrl":"/listmyAudited","sysType":null,"icon":"","children":[]},{"id":788,"pid":768,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"我发起的","menuUrl":"/listmyApply","sysType":null,"icon":"","children":[]},{"id":789,"pid":768,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"审批流程设置","menuUrl":"/listFlowSet","sysType":null,"icon":"","children":[]}]},{"id":790,"pid":759,"menuType":1,"menuSort":null,"orderId":null,"menuName":null,"menuText":"系统监控","menuUrl":"/g","sysType":null,"icon":"ex_monitor","children":[{"id":791,"pid":790,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"前置机监控","menuUrl":"/frontMachineMonitoring","sysType":null,"icon":"","children":[]},{"id":792,"pid":790,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"订阅监控","menuUrl":"/subscribeMonitoring","sysType":null,"icon":"","children":[]},{"id":793,"pid":790,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"上报监控","menuUrl":"/reporteMonitoring","sysType":null,"icon":"","children":[]},{"id":794,"pid":790,"menuType":2,"menuSort":null,"orderId":null,"menuName":null,"menuText":"异常预警","menuUrl":"/exceptionWarning","sysType":null,"icon":"","children":[]}]}]}]}
    }
  },   
  components: {
    ComHeader,
    ComAside
//  vTags
  },
  created () {
    let $this =this;
    setTimeout(function(){
      $this.projectdetail.system = 2
      //系统图标
      $this.projectdetail.system_log = '3'
      $this.projectdetail.backUrl = 'http://bigdev02.isky.com:8500/'
      // "backUrl":"http://bigdev02.isky.com:8500/"
      // this.$store.commit('setAllMenu', $this.projectdetail)
      // console.log($this.$store.state.allMenu)
      storeCom.commit('setAllMenu', $this.projectdetail)
    },1000)
  },
  components : {
    ComHeader,
    ComAside
  }  
}
</script>

<style scoped>
  #app {
    position: absolute;
    width: 100%;
    height: 100%;
  }
  .el-container {
    width: 100%;
    height: 100%;
  }
  .el-header {
    /*background-color: #B3C0D1;*/
    background-color: #4382e6;
    color: #333;
    text-align: center;
    line-height: 70px;
    height: 70px;
  }
  /*.el-aside {
    background-color: #D3DCE6;
    color: #333;
    text-align: center;
    line-height: 200px;
  }*/
  .el-main {
    /*background-color: #E9EEF3;*/
    background-color: #FFFFFF;
    color: #333;
    padding: 12px;
    /*text-align: center;*/
    /*line-height: 160px;*/
  }
  .main_con {
    height: calc(100% - 49px);
    overflow: auto;
    border: 1px solid #ccc;
    /* border-bottom: 1px solid #ccc;
    border-left: 1px solid #ccc;
    border-right: 1px solid #ccc; */
  }
  body>.el-container {
    margin-bottom: 40px;
  }
</style>

