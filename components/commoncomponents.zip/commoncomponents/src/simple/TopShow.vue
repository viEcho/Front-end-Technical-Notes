<!--头部样例-->
<template>
<div id="topList">
nihhawww
</div>
</template>

<script>
export default {
  name: "topshow",

  components : {

  }
}
</script>

<style>
</style>