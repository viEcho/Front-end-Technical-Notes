<template>
  <div id="service_aside">
    <span @click="collapse_show" ref='collapse_show'  class="icon_collapse"></span>
    <el-menu :default-active="onRoutes" class="el-menu-vertical-demo" @open="handleOpen" @close="handleClose" :collapse="isCollapse" unique-opened router v-if="items.length > 0">
      <template v-for="item in items">
        <el-submenu :index="item.menuUrl" :key="item.id" v-if="item.children.length>0 && item.menuType === 1" >
          <template slot="title">
            <i class='item.icon white_right' :style="{ 'background': 'url(' + require('../imgs/'+item.icon+'.png') + ') no-repeat center'}" v-if="item.icon"></i>
            <i class='item.icon white_right' v-else></i>
            <span slot="title">{{ item.menuText }}</span>
          </template>
          <div v-if="item.children.length > 0">
          <template v-for="subItem in item.children">
            <el-submenu :index="subItem.menuUrl" :key="subItem.id" v-if="subItem.children.length > 0 && subItem.menuType === 1">
              <template slot="title">
                <i class="temp.icon white_right" :style="{ 'background': 'url(' + require('../imgs/'+nextMenumIcon.icon+'.png') + ') no-repeat center'}" v-if="subItem.children && subItem.children.length>0"></i>
                <span>{{subItem.menuText}}</span>
                </template>
              <div v-for="subItemChild in subItem.children" :key="subItemChild.id">
              <el-menu-item-group  :key="subItemChild.id"  v-if="subItemChild.menuType === 2">
                <el-menu-item :index="subItemChild.menuUrl">{{subItemChild.menuText}}</el-menu-item>
              </el-menu-item-group>
              </div>
            </el-submenu>
            <el-menu-item-group  :key="subItem.id" v-else-if="subItem.menuType === 2">
              <el-menu-item :index="subItem.menuUrl"><i class="temp"></i>{{subItem.menuText}}</el-menu-item>
            </el-menu-item-group>            
          </template>            
          </div>
        </el-submenu>
        <el-menu-item-group  :key="item.id" v-else-if="item.menuType === 2">
          <el-menu-item :index="item.menuUrl"><i class="temp"></i>{{item.menuText}}</el-menu-item>
        </el-menu-item-group>      
      </template>
    </el-menu>
  </div>
</template>

<script>
   import bus from "./bus.js";
   import storeCom from '../../src/utils/store.js'
export default {
  data () {
    return {
      isCollapse: false,
      retate:90,
      menuData: [],
      allMenu:{},
      allMenuChildren:[],
      flagCurrent: 0 ,
      items: [],
      nextMenumIcon: {icon: 'sanjiao-right'}
    };
  },
  created() {
    let $this = this;
//  this.allMenu = this.$store.state.allMenu;
    this.allMenu = storeCom.state.allMenu;
    // 通过地址栏输入时，侧边栏相应渲染跳转到地址栏匹配
    bus.$on("asideTog" , msg => {
      if(msg.curIndex){
        $this.flagCurrent = String(msg.curIndex - 1);
        $this.items =msg.menu[0].children;
        var curUrl = $this.$route.path
        this.$router.push({ path: curUrl})        
      }else{
        $this.items =msg.menuList[0].children;
      }

    });
    // 主要解决点击头部时，该子集下的第一级显示
    bus.$on("asideIndex" , msg =>{
      if($this.items.length > 0){
        if($this.items[0].children.length > 0){
          this.$router.push({ path: $this.items[0].children[0].menuUrl});
        }else{
          this.$router.push({ path: $this.items[0].menuUrl});
        }        
      }
    })
  }, 
    // 监听菜单变化，解决第一次进入时store里面出现空值的情况
    computed: {
      isFollow() {
        return storeCom.state.allMenu;
      },
      onRoutes() {
        return this.$route.path;
      }
  },      
  watch: {
      isFollow(newVal, oldVal) {
        if (newVal.system === 1) {
          var menuList = newVal.menuList[0] ;
          this.items = menuList.children[this.flagCurrent].children;
          this.allMenuChildren = newVal.menuList[0].children;
        }else{
          this.items = newVal.menuList[0].children;
        }
      }  
},  
  methods: {
    collapse_show () {
      this.isCollapse = !this.isCollapse;
      this.$refs.collapse_show.style.transform = `rotate(${this.retate}deg)`
      this.retate += 90;
    },
    //菜单栏的折叠
    collapseChage() {
      this.collapse = !this.collapse;
      bus.$emit("collapse", this.collapse);
    },    
    handleOpen (key, keyPath) {
    },
    handleClose (key, keyPath) {
    },
    // 数字转为字符串
    gernerateId(index){
       return index
    }
  }
}
</script>

<style lang="scss">
/*#service_aside{
  padding-top: 39px;
  position: relative;
  background-color: #2e4e89;  
}
#service_aside .icon_collapse{
  width: 20px;
  height: 14px;
  cursor: pointer;
  background: url(../imgs/list.png) no-repeat center;
  position: absolute;
  right: 12px;
  top: 12px;  
}
#service_aside .el-menu-vertical-demo:not(.el-menu--collapse){
  width: 200px;
  min-height: 400px;
  overflow-y: auto;
  max-height: 100%;
  background-color: #2e4e89;  
}
#service_aside .el-submenu {
  background: #2e4e89;
  max-width: 177px;
  margin: 0 auto;  
}
#service_aside .el-submenu .el-submenu__title{
  background: #fff;
  border-radius: 15px;
  height: 32px;
  line-height: 32px;
  margin: 5px 0;
  color: #333 ;  
}
#service_aside .el-submenu .el-submenu__icon-arrow {
  right: 10px;
}
#service_aside .el-submenu .el-submenu__title:hover {
  background: #fff;
  border-radius: 15px;
  height: 32px;
  line-height: 32px;
  margin: 5px 0;
  color: #333 !important;
}
#service_aside .el-submenu .el-menu-item-group .el-menu-item-group__title {
  padding: 0px;
} 
#service_aside .el-submenu .el-menu-item-group .el-menu-item {
  color: #FFFFFF;
  margin-bottom: 2px;
  height: 32px;
  line-height: 32px;
  min-width: 0;
  padding-left: 20px !important;
}
#service_aside .el-submenu .el-menu-item-group .is-active {
  background: #173876;
  border-radius: 15px;
}
#service_aside .el-submenu .el-menu-item-group .el-menu-item:hover {
  background: #173876;
  border-radius: 15px;
}
#service_aside .el-main {
  background-color: #fff;
  padding: 12px;
}
  #service_aside .el-menu {
    background: none;
  }
  .white_right {
    display: inline-block;
    width: 20px;
    height: 20px;
    margin-right: 10px;
  }
  .temp {
    margin-right: 10px;
    display: inline-block;
    width: 20px;
    height: 20px;
  }
  .el-menu-item-group ul li{
    color: #FFFFFF;
    height: 32px;
    line-height: 32px;
    min-width: 0;
    padding-left: 20px !important;
    max-width: 177px;
    margin: 0 auto;
    margin-bottom: 2px;
    text-align: center;
  }
  .el-menu-item-group ul li:hover {
        background: #173876;
    border-radius: 15px;
  }
  .el-menu-item-group ul li.is-active {
    background: #173876;
    border-radius: 15px;
    color: #FFFFFF;
  }
  ul li ul li.el-submenu .el-submenu__title{
    background: none!important;
    color: #FFFFFF!important;
  }
  ul li ul li.el-submenu:hover{
    color: #FFFFFF!important;
  }  */
  #service_aside {
    width: 200px;
    padding-top: 39px;
    position: relative;
    background-color: #2e4e89;
    .icon_collapse {
      width: 20px;
      height: 14px;
      cursor: pointer;
      background: url(../imgs/list.png) no-repeat center;
      position: absolute;
      right: 12px;
      top: 12px;
    }
    .el-menu-vertical-demo:not(.el-menu--collapse) {
      width: 200px;
      min-height: 400px;
      overflow-y: auto;
      max-height: 100%;
      background-color: #2e4e89;
    }
    .el-submenu {
      background: #2e4e89;
      max-width: 177px;
      margin: 0 auto;
      .el-submenu__title {
        background: #fff;
        border-radius: 15px;
        height: 32px;
        line-height: 32px;
        margin: 5px 0;
        color: #333 ;
        .el-submenu__icon-arrow {
          right: 10px;
        }
        .el-submenu__icon-arrow:before{
          content:url('../imgs/menu-close.png')
        }
      }
      .el-submenu__title:hover {
        background: #fff;
        border-radius: 15px;
        height: 32px;
        line-height: 32px;
        margin: 5px 0;
        color: #333 !important;
      }
      .el-menu-item-group {
        .el-menu-item-group__title {
          padding: 0px;
        }
        .el-menu-item {
          color: #FFFFFF;
          margin-bottom: 2px;
          height: 32px;
          line-height: 32px;
          min-width: 0;
          padding-left: 25px !important;
          //padding-left: 24px !important;
        }
        .is-active {
          background: #173876;
          border-radius: 15px;
        }
        .el-menu-item:hover {
          background: #173876;
          border-radius: 15px;
        }
      }
    }
    .el-submenu.is-opened{
        .el-submenu__title .el-submenu__icon-arrow{
          top: 65%;
        }
        .el-submenu__icon-arrow::before {
          content:url('../imgs/menu-open.png');
        }
        .el-submenu {
          .el-submenu__icon-arrow::before {
            //content:url('../imgs/menu-close.png');
            content:''
          }           
        }
        .el-submenu.is-opened {
          .el-submenu__icon-arrow::before {
            //content:url('../imgs/menu-open.png');
            content:''
          }     
        }
    }
    
    .el-main {
      background-color: #fff;
      padding: 12px;
    }
  }
  #service_aside .el-menu {
    background: none;
  }
  #service_aside .el-menu .is-opened ul div .is-opened {
    .white_right{
      transform: rotate(90deg);
    }
    ul div{
      padding-left: 30px;
    }
  }
  #service_aside .el-menu .el-submenu ul div li{
    ul div{
      padding-left: 44px !important;
    }
    .el-submenu__title{
      padding-left: 20px !important;
    }
  }

  #service_aside ul .el-submenu ul div .el-submenu .el-submenu__title i::before{
    content:''
  }
  .white_right {
    display: inline-block;
    width: 20px;
    height: 20px;
    margin-right: 10px;
  }
  .temp {
    margin-right: 10px;
    display: inline-block;
    width: 20px;
    height: 20px;
  }
  .el-menu-item-group ul li{
    color: #FFFFFF;
    height: 32px;
    line-height: 32px;
    min-width: 0;
    padding-left: 20px !important;
    max-width: 177px;
    margin: 0 auto;
    margin-bottom: 2px;
    text-align: left;
  }
  .el-menu-item-group ul li:hover {
        background: #173876;
    border-radius: 15px;
  }
  .el-menu-item-group ul li.is-active {
    background: #173876;
    border-radius: 15px;
    color: #FFFFFF;
  }
  ul li ul li.el-submenu .el-submenu__title{
    background: none!important;
    color: #FFFFFF!important;
  }
  ul li ul li.el-submenu:hover{
    color: #FFFFFF!important;
  }
</style>
