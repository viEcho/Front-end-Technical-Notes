<template>
  <div id='top'>
    <div class="logo-e">
      <div class="left_logo">
          <div :class="'sysLogo'+allMenu.system_log"></div>
          <span v-if="IsallMenu">{{allMenu.menuList[0].menuText}}</span>
      </div>
      <div class="component">
        <el-menu class="el-menu-demo" :default-active="activeNav" mode="horizontal" @select="handleSelect" background-color="#4382e6" text-color="#fff">
          <el-menu-item v-for="(item, index) in stairMenu" :key="index" :keyId="item.id" :index="index+1+''">
            <router-link :to="item.menuUrl">{{item.menuText}}</router-link>
          </el-menu-item>
        </el-menu>
      </div>
      <div class="right_logo">
        <div class="show_info">
          <div class="admin_name"></div>
          <div class="admin_detail">
            <span class="admin_account">{{allMenu.username}}</span>
            <!-- <span class="admin_add">{{allMenu.deptName}}</span> -->
          </div>
        </div>
        <div class="logout" @click="logout">
          <!-- <span>退出</span> -->
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import bus from "./bus.js";
  import qs from 'qs';
  import storeCom from '../../src/utils/store.js'
  export default {
    name: "top",
    data() {
      return {
        activeNav: "1",
        allMenu: {},
        stairMenu: [],
        IsallMenu: false,
        sysLog: ''
      };
    },
    created() {
      var curPath = this.$route.path
      this.allMenu = storeCom.state.allMenu
      //  菜单
      if(this.allMenu && this.allMenu.system === 1){
        this.stairMenu = this.allMenu.menuList[0].children
      }
      // 系統log
      // this.sysLog = 'url(../imgs/'+this.allMenu.sysLog+'.png)'
    },
    // 监听菜单变化，解决第一次进入时store里面出现空值的情况
    computed: {
      isFollow() {
        return storeCom.state.allMenu
      },
      isActiveNav(){
        return this.activeNav
      }
    },
    watch: {
      isFollow(newVal, oldVal) {
        this.allMenu = newVal
        this.IsallMenu = true
        if(this.allMenu && this.allMenu.system === 1){
          this.stairMenu = this.allMenu.menuList[0].children
          var objs = this.menuTrue(this.$route.path,this.allMenu)
          this.activeNav = String(objs.curIndex)
          bus.$emit("asideTog", objs);
        }else{
          bus.$emit("asideTog", this.allMenu)
        }
      },
      //      通过路由来判断该渲染哪个，传给侧边栏
      $route(to,from){
        if(this.allMenu.system === 1){
          var objs = this.menuTrue(to.path,this.allMenu)
          this.activeNav = String(objs.curIndex)
          bus.$emit("asideTog", objs);          
        }else{
          bus.$emit("asideTog", this.allMenu)
        }
     },
     isActiveNav(newNav,oldNav){
     }
    },
    methods: {
      // 传入当前的路由，以及所有菜单栏，来判断头部哪个选中，哪些子菜单在侧边栏显示
      menuTrue(curUrl,projectdetail){
        var curArray = projectdetail.menuList[0].children
        var curIndex, menuObj={}
        var curMenu = curArray.filter(function(item,index){
          if(JSON.stringify(item).includes(curUrl)){
            curIndex = index
            return item
          }
        })
        menuObj.menu = curMenu;
        menuObj.curIndex = curIndex+1
        return menuObj
       },      
       // 点击时传给侧边栏值
      handleSelect(key, keyPath,keyId) {
        bus.$emit("asideIndex", key)
      },      
      //登出
      logout() {
        //    window.sessionStorage.removeItem('asideTog');
        //    window.sessionStorage.removeItem('menuList');
        //    window.sessionStorage.removeItem('stairMenu');
        //    window.sessionStorage.removeItem('userInfo');
        //window.location.href = 'http://bigdev02.isky.com:8500/'
        window.location.href = this.allMenu.backUrl
      }
    }

  }
</script>

<style scoped>
  #app #top .sysLogo1,.sysLogo2,.sysLogo3,.sysLogo4,.sysLogo5,.sysLogo6{
    display:inline-block;
    width: 34px;
    height: 34px;
    position: relative;
    top: 15%;
    left: -2%;
    background-repeat: no-repeat;
    background-size: 34px 34px;
    margin-top: 1px;
  }
  #app #top .sysLogo1{
    background-image:url('../imgs/sys-log1.png');  
  }
  #app #top .sysLogo2{
    background-image:url('../imgs/sys-log2.png');  
  }
  #app #top .sysLogo3{
    background-image:url('../imgs/sys-log3.png');  
  }
  /*#app #top .sysLogo4{
     background-image:url('../imgs/sys-log4.png');   
  }*/
  #app #top .sysLogo5{
    background-image:url('../imgs/sys-log5.png');  
  }
  #app #top .sysLogo6{
    background-image:url('../imgs/sys-log6.png');  
  }

  #app #top .el-menu--horizontal>.el-menu-item {
    float: left;
    height: 50px;
    line-height: 50px;
    margin: 0;
    border-bottom: 2px solid transparent;
    color: #909399;
    font-size: 16px;
    font-weight: 700;
    border-radius: 20px;
  }
  
  #app #top .el-menu.el-menu--horizontal {
    border-bottom: none;
  }
  
  #app #top .el-menu--horizontal>.el-menu-item.is-active {
    color: #fff;
    background-color: #2862c0 !important;
    border-radius: 20px;
  }
  
  #app #top .el-menu-item:hover {
    background: #2e4e89;
    border-radius: 20px;
  }
  
  #top .logo-e {
    width: 100%;
    height: 70px;
    position: relative;
    background-color: #4382e6;
  }
  
  #top .left_logo {
    height: 70px;
    float: left;
    line-height: 70px;
    margin-left: 24px;
    font-size: 20px;
    font-weight: 700;
    color: #fff;
  }
  #top .log_png{
    position: relative;
    top: 13%;
  }

  #top .logo-e .component {
    position: absolute;
    left: 50%;
    height: 50px;
    font-size: 0px;
    margin-left: -284px;
    top: 10px;
  }
  
  #top .logo-e .component a {
    display: inline-block;
    line-height: 50px;
    height: 50px;
    font-size: 16px;
    cursor: pointer;
    color: #fff;
    font-weight: 700;
    padding: 0 10px;
  }
  
  #top .right_logo {
    width: 207px;
    height: 70px;
    float: right;
    line-height: 70px;
  }
  
  #top .right_logo .show_info {
    position: relative;
    z-index: 1;
    width: 150px;
    height: 40px;
    margin-top: 12px;
    display: inline-block;
    border-radius: 72px;
  }
  
  #top .right_logo .show_info .admin_name {
    display: inline-block;
    width: 36px;
    height: 36px;
    background-image: url(../imgs/department.png);
    background-repeat: no-repeat;
    background-size: 36px 36px;
    margin-top: 1%;
  }
  
  #top .right_logo .show_info .admin_detail {
    padding-left: 10px;
    width: 103px;
    height: 40px;
    float: right;
  }
  
  #top .right_logo .show_info .admin_detail span {
    display: block;
    height: 20px;
    font-family: "Arial", "Microsoft Yahei", "sans-serif";
    font-size: 12px;
    color: rgba(255, 255, 255, 0.80);
    letter-spacing: 0;
    text-align: left;
    line-height: 20px;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    padding-right: 16px;
  }
  
  #top .right_logo .show_info .admin_detail .admin_account {
    color: rgba(255, 255, 255, 0.80);
    margin-top: 12%;
  }
  
  #top .right_logo .logout {
    width: 24px;
    height: 24px;
    margin-top: 20px;
    margin-right: 20px;
    float: right;
    text-align: center;
    background-image: url('../imgs/log-out.png');
    padding-bottom: 2px;
    cursor: pointer;
    background-size: cover;
  }
  #top .right_logo .logout span {
    font-family: "Arial", "Microsoft Yahei", "sans-serif";
    font-size: 12px;
    color: #92BEE1;
    letter-spacing: 0;
    cursor: pointer;
  }
</style>