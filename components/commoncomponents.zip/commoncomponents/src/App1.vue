<template>
  <div id="app">
    <!--<img src="./assets/logo.png">-->
      <com-header></com-header>
      <com-aside></com-aside>
    <router-view/>
  </div>
</template>

<script>
import ComHeader from './components/ComHeader'
import ComAside from './components/ComAside'
export default {
  name: 'App',
  components: {
    ComHeader,
    ComAside
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  /*margin-top: 60px;*/
}
</style>
