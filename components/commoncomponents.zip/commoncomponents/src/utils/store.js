/**
 * Created by aixin on 2018/12/12.
 */
import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const store = new Vuex.Store({
  state: {
    allMenu: {}, // 存储菜单集合
    
  },
  mutations: {
    setAllMenu (state, allMenu) { // 保存history方法
      state.allMenu = allMenu
    }
  }
})

export default store
